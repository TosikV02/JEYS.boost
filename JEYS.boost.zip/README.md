The entire magisk module is based exclusively on open source code. if you will take the magisk module under modification or fork, then mark the authors!
Made by the project | Telegram @saltfor